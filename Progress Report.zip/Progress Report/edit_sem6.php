<?php require 'includes/session.php'; ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<title>Add Students</title>
		<link rel="stylesheet" href="css/style.css" type="text/css" />
		<link
			rel="stylesheet"
			href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
		/>
		<link
			href="https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css"
			rel="stylesheet"
		/>
	</head>
	<?php require 'includes/sidebar.php';  ?>
	<body id="body-pd">
    <?php 
      require 'includes/connection.php';
      $ROLLNO = $_GET['ROLLNO'];
      $row = mysqli_fetch_array(mysqli_query($connection,"SELECT * FROM semester6 WHERE ROLLNO = $ROLLNO"));
    ?>
		<form class="mt-5 pt-5" action="update_sem6.php?ROLLNO=<?php echo $ROLLNO ?>" method="POST">
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">Roll No.</label>
						<input type="number" readonly value="<?php echo $row['ROLLNO'] ?>" name="ROLLNO" class="form-control" id="inputEmail4" placeholder="Student Roll number" />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">Major Project</label>
						<input type="number" value="<?php echo $row['MAJOR_PROJECT'] ?>" name="MAJOR_PROJECT" class="form-control" id="inputPassword4" placeholder="mark" />
					</div>
				</div>
				<button type="submit" class="btn btn-primary">Submit</button>
			</form>
		<script src="js/main.js"></script>
	</body>
</html>
