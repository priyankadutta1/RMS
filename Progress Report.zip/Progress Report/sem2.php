<form action="insert_sem2.php" method="post" >
				<div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">ROLL NO</label>
						<input type="number" name="ROLLNO" class="form-control" id="inputEmail4" placeholder="Student Roll number" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">DS</label>
						<input type="number" name="DS" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">CAO</label>
						<input type="number" name="CAO" class="form-control" id="inputEmail4" placeholder="mark" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">MATHEMATICS 2</label>
						<input type="number" name="MATHS_2" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">HUMANITIES 2</label>
						<input type="number" name="HUM_2" class="form-control" id="inputEmail4" placeholder="mark" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">ENV SCIENCE</label>
						<input type="number" name="ENV_SCIENCE" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">DS LAB</label>
						<input type="number" name="DS_LAB" class="form-control" id="inputEmail4" placeholder="mark" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">CAO LAB</label>
						<input type="number" name="CAO_LAB" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<button type="submit" class="btn btn-primary">Submit</button>
				</div>
			</form>