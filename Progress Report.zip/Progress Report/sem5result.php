<?php 
  $query="SELECT * FROM semester5";
	$result=mysqli_query($connection,$query);
?>
<table class="table table-bordered table-striped">
	<thead>
		<tr>
			<th scope="col">ROLLNO</th>
			<th scope="col">WT</th>
			<th scope="col">ES</th>
			<th scope="col">AI</th>
			<th scope="col">SE</th>
			<th scope="col">MS</th>
			<th scope="col">WT-LAB</th>
			<th scope="col">MINOR-PROJECT</th>
			<th scope="col">TOTAL</th>
			<th scope="col">PERCENTAGE</th>
			<?php if(isset($_SESSION['NAME'])): ?>
			<th scope="col">ACTION</th>
			<?php endif ?>
		</tr>
	</thead>
	<tbody>
		<?php if(mysqli_num_rows($result)>=1){ while($row=mysqli_fetch_array($result)){ ?>
		<tr>
			<td><?php echo $row['ROLLNO'] ?></td>
			<td><?php echo $row['WT']; ?></td>
			<td><?php echo $row['ES']; ?></td>
			<td><?php echo $row['AI']; ?></td>
			<td><?php echo $row['SE']; ?></td>
			<td><?php echo $row['MS']; ?></td>
			<td><?php echo $row['WT_LAB']; ?></td>
			<td><?php echo $row['MINOR_PROJECT']; ?></td>
			<td>
				<?php echo ($row['WT']+$row['ES']+$row['AI']+$row['SE']+$row['MS']+$row['WT_LAB']+ $row['MINOR_PROJECT']) ?>
			</td>
			<td>
				<?php echo round(($row['WT']+$row['ES']+$row['AI']+$row['SE']+$row['MS']+$row['WT_LAB']+ $row['MINOR_PROJECT'])/700*100)."%" ?>
			</td>
			<?php if(isset($_SESSION['NAME'])): ?>
			<td>
				<a href="edit_sem5.php?ROLLNO=<?php echo $row['ROLLNO'] ?>"
					>Edit<i class="fas fa-edit ml-2"></i>
				</a>
			</td>
			<?php endif ?>
		</tr>
		<?php }} else{ ?>
		<tr>
			<td colspan="10" align="center">RECORD NOT FOUND</td>
		</tr>
		<?php } ?>
	</tbody>
</table>
