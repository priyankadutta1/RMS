<?php
session_start();
include "includes/connection.php";
$email = $_POST['email'];
$password = $_POST['password'];


$sql = "SELECT * from student where email='$email'";
$result = mysqli_query($connection,$sql);

if(mysqli_num_rows($result)==1){
    $user = mysqli_fetch_array($result);
    
    if(password_verify($password, $user['PASSWORD'])){
        $_SESSION['ID']=$user['ID'];
        $_SESSION['SEMESTER']=$user['SEMESTER'];
        $_SESSION['ROLLNO']=$user['ROLLNO'];
        header("location:view_report.php"); 
    } else {
        // echo mysqli_error($connection);
        $_SESSION['error'] = "Bad Credential";
        header('location:index.php');
    }
}
else {
    // echo mysqli_error($connection);
    $_SESSION['error'] = "User not found";
    header('location:index.php');
}   
?>