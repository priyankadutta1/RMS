<?php
include 'includes/connection.php';

session_start();

$NAME = $_POST['NAME'];
$SEMESTER = $_POST['SEMESTER'];
$ROLLNO = $_POST['ROLLNO'];
$EMAIL = $_POST['EMAIL'];
$PASSWORD = $_POST['PASSWORD'];
$CONFIRM=$_POST['CONFIRM'];
$HASH_PASSWORD= password_hash($PASSWORD, PASSWORD_DEFAULT);

$sql = "SELECT EMAIL FROM student";
$result = mysqli_query($connection, $sql);
$row=mysqli_fetch_array($result);

if($PASSWORD==$CONFIRM){
    if($EMAIL != $row['EMAIL']){
    $sql = "INSERT INTO student (NAME, SEMESTER, ROLLNO, EMAIL, PASSWORD) VALUES('$NAME', '$SEMESTER', '$ROLLNO', '$EMAIL','$HASH_PASSWORD')";
    $result = mysqli_query($connection,$sql);
    if($result){
        $_SESSION['status']= "<h4> Registered successfully </h4>";
        header('location:student_signup.php?status=ok');
    }else{
        echo mysqli_error($connection);
        header('location:student_signup.php?status=failed');
    }
    }
    else{
        $_SESSION['status']= "<h4> User already exist! </h4>";
        header('location:student_signup.php?status=failed');
    }
}
else{
    $_SESSION['status']= "<h4>Password mismatch</h4>";
    header('location:student_signup.php?status=failed');
}
?>