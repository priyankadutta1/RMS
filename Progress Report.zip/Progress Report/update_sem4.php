<?php
include 'includes/connection.php';
session_start();
$ROLLNO = $_GET['ROLLNO'];
$VBP = $_POST['VBP'];
$DBMS = $_POST['DBMS'];
$FM = $_POST['FM'];
$CN = $_POST['CN'];
$CD = $_POST['CD'];
$VBP_LAB = $_POST['VBP_LAB'];
$DBMS_LAB = $_POST['DBMS_LAB'];
//  insert query 
    $sql = "UPDATE semester4 SET VBP='$VBP',DBMS='$DBMS',FM='$FM',CN='$CN',CD='$CD',VBP_LAB='$VBP_LAB',DBMS_LAB='$DBMS_LAB' WHERE ROLLNO='$ROLLNO'";
    $result = mysqli_query($connection,$sql);
    if($result){
         $_SESSION['status']= "<h5>Marks Edited Successfully </h5>";
        header('location:manage_reports.php?semester=4&&status=ok');
    }else{
        header('location:manage_reports.php?semester=4&&status=fail');
    }
?>