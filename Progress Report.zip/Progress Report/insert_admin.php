<?php
include 'includes/connection.php';
$NAME = $_POST['NAME'];
$EMAIL = $_POST['EMAIL'];
$PASSWORD = $_POST['PASSWORD'];
$CONFIRM=$_POST['CONFIRM'];
$HASH_PASSWORD= password_hash($PASSWORD, PASSWORD_DEFAULT);

if($PASSWORD==$CONFIRM){
    $sql = "INSERT INTO admin (NAME, EMAIL, PASSWORD) VALUES('$NAME', '$EMAIL','$HASH_PASSWORD')";
    $result = mysqli_query($connection,$sql);
    if($result){
        header('location:admin_signup.php?status=ok');
    }else{
        header('location:admin_signup.php?status=failed');
    }
}
else{
    header('location:admin_signup.php?status=failed');
}
?>