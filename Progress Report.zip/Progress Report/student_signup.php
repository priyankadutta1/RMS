<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700" />
		<title>Student Sign Up</title>
		<link
			rel="stylesheet"
			href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
		/>
		<link
			rel="stylesheet"
			href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
		/>
		<link rel="stylesheet" href="css/sign_up6.css" />
		<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
		<style></style>
	</head>
	<body>
		<div class="signup-form">
		<br>
			<?php session_start(); ?>
			<?php
                if(isset($_SESSION['status'])){

                  echo $_SESSION['status'] ;
                  unset($_SESSION['status']);
                }
            ?>
			<form action="insert_student.php" method="post">
				<h3>Sign Up</h3>
				<p>Please fill in this form to create an account!</p>
				<p>
			<?php 
            error_reporting(0);
            echo $_SESSION['error'];
            if(isset($_SESSION['error'])){
              unset($_SESSION['error']);  
            }
          ?>
				</p>
				<hr />
				<div class="form-group">
					<div class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text">
								<span class="fa fa-user"></span>
							</span>
						</div>
						<input
							type="text"
							class="form-control"
							name="NAME"
							placeholder="Username"
							required="required"
						/>
					</div>
				</div>
				<div class="form-group">
					<div class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text">
								<i class="fa fa-paper-plane"></i>
							</span>
						</div>
						<select class="form-control" name="SEMESTER">
							<option selected disabled>Select Semester</option>
							<option value="1">1st Semester</option>
							<option value="2">2nd Semester</option>
							<option value="3">3rd Semester</option>
							<option value="4">4th Semester</option>
							<option value="5">5th Semester</option>
							<option value="6">6th Semester</option>
						</select>
					</div>
				</div>
				<div class="form-group">
					<div class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text">
								<i class="fa fa-paper-plane"></i>
							</span>
						</div>
						<input
							type="number"
							class="form-control"
							name="ROLLNO"
							placeholder="Roll No"
							required="required"
						/>
					</div>
				</div>
				<div class="form-group">
					<div class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text">
								<i class="fa fa-paper-plane"></i>
							</span>
						</div>
						<input
							type="email"
							class="form-control"
							name="EMAIL"
							placeholder="Email Address"
							required="required"
						/>
					</div>
				</div>
				<div class="form-group">
					<div class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text">
								<i class="fa fa-lock"></i>
							</span>
						</div>
						<input
							type="password"
							class="form-control"
							name="PASSWORD"
							placeholder="Password"
							required="required"
						/>
					</div>
				</div>
				<div class="form-group">
					<div class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text">
								<i class="fa fa-lock"></i>
								<i class="fa fa-check"></i>
							</span>
						</div>
						<input
							type="password"
							class="form-control"
							name="CONFIRM"
							placeholder="Confirm Password"
							required="required"
						/>
					</div>
				</div>
				<div class="form-group">
					<button type="submit" class="btn btn-primary btn-lg">Sign Up</button>
					
				</div>
			</form>
			<div class="text-center last">Already have an account? <a href="index.php">Login here</a></div>
		</div>
	</body>
</html>
