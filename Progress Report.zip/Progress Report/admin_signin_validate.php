<?php
session_start();
include "includes/connection.php";
$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * from admin where email='$email'";
$result = mysqli_query($connection,$sql);

if(mysqli_num_rows($result)==1){
    $user = mysqli_fetch_array($result);
    
    if(password_verify($password, $user['PASSWORD'])){
        $_SESSION['ID']=$user['ID'];
        $_SESSION['NAME']=$user['NAME'];
        header("location:manage_reports.php"); 
    } else {
        $_SESSION['error'] = "Bad Credential";
        header('location:admin_signin.php');
    }
}
else {
    $_SESSION['error'] = "User not found";
    header('location:admin_signin.php');
}   
?>