<?php require 'includes/session.php'; ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<title>Add Students</title>
		<link rel="stylesheet" href="css/style.css" type="text/css" />
		<link
			rel="stylesheet"
			href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
		/>
		<link
			href="https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css"
			rel="stylesheet"
		/>
	</head>
	<?php require 'includes/sidebar.php';  ?>
	<body id="body-pd">
    <?php 
      require 'includes/connection.php';
      $ROLLNO = $_GET['ROLLNO'];
      $row = mysqli_fetch_array(mysqli_query($connection,"SELECT * FROM semester5 WHERE ROLLNO = $ROLLNO"));
    ?>
		<form class="mt-5 pt-5" action="update_sem5.php?ROLLNO=<?php echo $ROLLNO ?>" method="POST">
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">ROLL NO</label>
						<input type="number" readonly value="<?php echo $row['ROLLNO'] ?>" name="ROLNO" class="form-control" id="inputEmail4" placeholder="Student Roll number" />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">WT</label>
						<input type="number" value="<?php echo $row['WT'] ?>" name="WT" class="form-control" id="inputPassword4" placeholder="mark" />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">ES</label>
						<input type="number" value="<?php echo $row['ES'] ?>" name="ES" class="form-control" id="inputEmail4" placeholder="mark" />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">AI</label>
						<input type="number" value="<?php echo $row['AI'] ?>" name="AI" class="form-control" id="inputPassword4" placeholder="mark" />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">SE</label>
						<input type="number" value="<?php echo $row['SE'] ?>" name="SE" class="form-control" id="inputEmail4" placeholder="mark" />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">MS</label>
						<input type="number" value="<?php echo $row['MS'] ?>" name="MS" class="form-control" id="inputPassword4" placeholder="mark" />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">WT LAB</label>
						<input type="number" value="<?php echo $row['WT_LAB'] ?>" name="WT_LAB" class="form-control" id="inputEmail4" placeholder="mark" />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">MINOR PROJECT</label>
						<input type="number" value="<?php echo $row['MINOR_PROJECT'] ?>" name="MINOR_PROJECT" class="form-control" id="inputPassword4" placeholder="mark" />
					</div>
				</div>
				<button type="submit" class="btn btn-primary">Submit</button>
			</form>
		<script src="js/main.js"></script>
	</body>
</html>
