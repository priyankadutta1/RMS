<?php require 'includes/session.php'; ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<title>Add Students</title>
		<link rel="stylesheet" href="css/style.css" type="text/css" />
		<link
			rel="stylesheet"
			href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
		/>
		<link
			href="https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css"
			rel="stylesheet"
		/>
	</head>
	<?php require 'includes/sidebar.php';  ?>
	<body id="body-pd">
    <?php 
      require 'includes/connection.php';
      $ROLLNO = $_GET['ROLLNO'];
      $row = mysqli_fetch_array(mysqli_query($connection,"SELECT * FROM semester1 WHERE ROLLNO = $ROLLNO"));
    ?>
		<form class="mt-5 pt-5" action="update_sem1.php?ROLLNO=<?php echo $ROLLNO ?>" method="POST">
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">ROLL NO</label>
						<input type="number" readonly value="<?php echo $row['ROLLNO'] ?>" name="ROLLNO" class="form-control" id="inputEmail4" placeholder="Student Roll number" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">IIT</label>
						<input type="number" value="<?php echo $row['IIT'] ?>" name="IIT" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">CPPS</label>
						<input type="number" value="<?php echo $row['CPPS'] ?>" name="CPPS" class="form-control" id="inputEmail4" placeholder="mark" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">EC</label>
						<input type="number" value="<?php echo $row['EC'] ?>" name="EC" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">HUMANITIES 1</label>
						<input type="number" value="<?php echo $row['HUM_1'] ?>" name="HUM_1" class="form-control" id="inputEmail4" placeholder="mark" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">MATHEMATICS 1</label>
						<input type="number" value="<?php echo $row['MATHS_1'] ?>" name="MATHS_1" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">CPPS LAB</label>
						<input type="number" value="<?php echo $row['CPPS_LAB'] ?>" name="CPPS_LAB" class="form-control" id="inputEmail4" placeholder="mark" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">EC LAB</label>
						<input type="number" value="<?php echo $row['EC_LAB'] ?>" name="EC_LAB" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<button type="submit" class="btn btn-primary">Submit</button>
				
		

			</form>
		<script src="js/main.js"></script>
	</body>
</html>
