<?php 
  $query="SELECT * FROM semester3";
	$result=mysqli_query($connection,$query);
?>
<table class="table table-bordered table-striped">
	<thead>
		<tr>
			<th scope="col">ROLLNO</th>
			<th scope="col">OOPD</th>
			<th scope="col">TFCS</th>
			<th scope="col">MATHS-3</th>
			<th scope="col">OS</th>
			<th scope="col">CG</th>
			<th scope="col">OOPD-LAB</th>
			<th scope="col">CG-LAB</th>
			<th scope="col">TOTAL</th>
			<th scope="col">PERCENTAGE</th>
			<?php if(isset($_SESSION['NAME'])): ?>
			<th scope="col">ACTION</th>
			<?php endif ?>
		</tr>
	</thead>
	<tbody>
		<?php if(mysqli_num_rows($result)>=1){ while($row=mysqli_fetch_array($result)){ ?>
		<tr>
			<td><?php echo $row['ROLLNO'] ?></td>
			<td><?php echo $row['OOPD']; ?></td>
			<td><?php echo $row['TFCS']; ?></td>
			<td><?php echo $row['MATHS_3']; ?></td>
			<td><?php echo $row['OS']; ?></td>
			<td><?php echo $row['CG']; ?></td>
			<td><?php echo $row['OOPD_LAB']; ?></td>
			<td><?php echo $row['CG_LAB']; ?></td>
			<td>
				<?php echo ($row['OOPD']+$row['TFCS']+$row['MATHS_3']+$row['OS']+$row['CG']+$row['CG_LAB']+ $row['OOPD_LAB']) ?>
			</td>
			<td>
				<?php echo round(($row['OOPD']+$row['TFCS']+$row['MATHS_3']+$row['OS']+$row['CG']+$row['CG_LAB']+ $row['OOPD_LAB'])/700*100)."%" ?>
			</td>
			<?php if(isset($_SESSION['NAME'])): ?>
			<td>
				<a href="edit_sem3.php?ROLLNO=<?php echo $row['ROLLNO'] ?>"
					>Edit<i class="fas fa-edit ml-2"></i>
				</a>
			</td>
			<?php endif ?>
		</tr>
		<?php }} else{ ?>
		<tr>
			<td colspan="10" align="center">RECORD NOT FOUND</td>
		</tr>
		<?php } ?>
	</tbody>
</table>
