<?php
  require 'includes/session.php';
  require 'includes/connection.php';
	$sql = "SELECT * FROM student WHERE ROLLNO =".$_SESSION['ROLLNO'];
  $student = mysqli_fetch_array(mysqli_query($connection,$sql));
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<title>Add Students</title>
		<link rel="stylesheet" href="css/style.css" type="text/css" />
		<script src="https://kit.fontawesome.com/a076d05399.js"></script>
		<link
			rel="stylesheet"
			href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
		/>
		<link
			href="https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css"
			rel="stylesheet"
		/>
	</head>
	<?php require 'includes/sidebar.php' ?>
	<body id="body-pd">
		<div class="row mt-5 p-4">
			<form action="update_student.php?ROLLNO=<?php echo $student['ROLLNO'] ?>" method="POST">
				<div>
					<h3>My Profile</h3><hr><br>
				</div>
				<div class="form-row">
				
					<div class="form-group col-md-6">
						<label for="inputPassword4">SEMESTER</label>
						<input type="number" readonly name="SEMESTER" value="<?php echo $student['SEMESTER'] ?>" class="form-control" id="inputPassword4" placeholder="mark" />
					</div>
					<div class="form-group col-md-6">
						<label for="inputEmail4">ROLLNO</label>
						<input type="number" readonly name="ROLLNO" value="<?php echo $student['ROLLNO'] ?>" class="form-control" id="inputEmail4" placeholder="mark" />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">NAME</label>
						<input type="text" name="NAME" value="<?php echo $student['NAME'] ?>" class="form-control" id="inputEmail4" placeholder="" />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">EMAIL</label>
						<input type="email" name="EMAIL" value="<?php echo $student['EMAIL'] ?>" class="form-control" id="inputPassword4" placeholder="mark" />
					</div>
				</div>
				<button type="submit" class="btn btn-primary">Submit</button>
			</form>
		</div>
		<script src="js/main.js"></script>
		<div style="color:red;">
		<?php
                if(isset($_SESSION['status'])){

                  echo $_SESSION['status'] ;
                  unset($_SESSION['status']);
                }
            ?>
			</div>
	</body>
</html>
