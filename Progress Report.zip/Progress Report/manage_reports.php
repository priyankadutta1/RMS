<?php
	require 'includes/session.php';
  require 'includes/connection.php';
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<title>Add Students</title>
		<link rel="stylesheet" href="css/style.css" type="text/css" />
		<script src="https://kit.fontawesome.com/a076d05399.js"></script>
		<link
			rel="stylesheet"
			href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
		/>
		<link
			href="https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css"
			rel="stylesheet"
		/>
	</head>
	<?php require 'includes/sidebar.php' ?>
	<body id="body-pd">
		<div class="row mt-5 p-4">
			
			
			<div class="form-group mt-2 col-md-4">
			<div>
				<h3 >Manage Student Reports</h3><hr><br>
			</div>

			<label for="inputState" class="m-3">FILTER SEMESTER REPORT</label>
				<select
					id="inputState"
					class="form-control"
					onchange="window.location.href='manage_reports.php?semester='+this.value"
				>
					<option disabled selected>Choose...</option>
						<?php for($i=1;$i<=6;$i++): ?>
							<option <?php if(isset($_GET['semester'])){ if($_GET['semester']==$i){?> selected <?php }} ?> value="<?php echo $i ?>">
								SEMESTER <?php echo $i ?>
							</option>
						<?php endfor ?>
				</select>
			</div>
			<div style="color:red; margin-top:15px;">
		<?php
                if(isset($_SESSION['status'])){

                  echo $_SESSION['status'] ;
                  unset($_SESSION['status']);
                }
            ?>
			</div>
			<?php 
			if(isset($_GET['semester'])){
				$semester = $_GET['semester'];
				switch($semester){
					case "1": require "sem1result.php";break;
					case "2": require "sem2result.php";break;
					case "3": require "sem3result.php";break;
					case "4": require "sem4result.php";break;
					case "5": require "sem5result.php";break;
					case "6": require "sem6result.php";break;
				}
			}
		?>
		</div>
		<script src="js/main.js"></script>
	</body>
</html>
