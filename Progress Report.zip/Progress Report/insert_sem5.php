<?php
include 'includes/connection.php';
session_start();
$ROLLNO = $_POST['ROLLNO'];
$WT = $_POST['WT'];
$ES = $_POST['ES'];
$AI = $_POST['AI'];
$SE = $_POST['SE'];
$MS = $_POST['MS'];
$WT_LAB = $_POST['WT_LAB'];
$MINOR_PROJECT = $_POST['MINOR_PROJECT'];
//  insert query 
    $sql = "INSERT INTO semester5 (ROLLNO, WT ,ES ,AI, SE, MS , WT_LAB , MINOR_PROJECT ) VALUES('$ROLLNO','$WT','$ES','$AI','$SE','$MS','$WT_LAB','$MINOR_PROJECT')";
    $result = mysqli_query($connection,$sql);
    if($result){
        $_SESSION['status']= "<h4> Marks Added Successfully </h4>";
        header('location:add_results.php?status=ok');
    }else{
        $_SESSION['status']= "<h4> Fail to Add Marks </h4>";
        header('location:add_results.php?status=fail');
    }
?>