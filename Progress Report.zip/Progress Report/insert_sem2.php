<?php
include 'includes/connection.php';
session_start();
$ROLLNO = $_POST['ROLLNO'];
$DS = $_POST['DS'];
$CAO = $_POST['CAO'];
$ENV_SCIENCE = $_POST['ENV_SCIENCE'];
$HUM_2 = $_POST['HUM_2'];
$MATHS_2 = $_POST['MATHS_2'];
$CAO_LAB = $_POST['CAO_LAB'];
$DS_LAB = $_POST['DS_LAB'];
//  insert query 
    $sql = "INSERT INTO semester2 (ROLLNO, DS ,CAO ,ENV_SCIENCE, HUM_2, MATHS_2 ,DS_LAB, CAO_LAB ) VALUES('$ROLLNO','$DS','$CAO','$ENV_SCIENCE','$HUM_2','$MATHS_2','$DS_LAB','$CAO_LAB')";
    $result = mysqli_query($connection,$sql);
    if($result){
      $_SESSION['status']= "<h4> Marks Added Successfully </h4>";
        header('location:add_results.php?status=ok');
    }else{
      // echo mysqli_error($connection);
      $_SESSION['status']= "<h4> Fail to Add Marks </h4>";
      header('location:add_results.php?status=fail');
    }
?>