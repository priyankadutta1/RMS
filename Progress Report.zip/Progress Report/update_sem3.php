<?php
include 'includes/connection.php';
session_start();
$ROLLNO = $_GET['ROLLNO'];
$OOPD = $_POST['OOPD'];
$TFCS = $_POST['TFCS'];
$MATHS_3 = $_POST['MATHS_3'];
$OS = $_POST['OS'];
$CG = $_POST['CG'];
$OOPD_LAB = $_POST['OOPD_LAB'];
$CG_LAB = $_POST['CG_LAB'];
//  insert query 
    $sql = "UPDATE semester3 SET OOPD='$OOPD',TFCS='$TFCS',MATHS_3='$MATHS_3',OS='$OS',CG='$CG',OOPD_LAB='$OOPD_LAB',CG_LAB='$CG_LAB' WHERE ROLLNO='$ROLLNO'";
    $result = mysqli_query($connection,$sql);
    if($result){
         $_SESSION['status']= "<h5>Marks Edited Successfully </h5>";
        header('location:manage_reports.php?semester=3&&status=ok');
    }else{
    //  echo mysqli_error($connection);
        header('location:manage_reports.php?semester=3&&status=fail');
    }
?>