<header class="header" id="header">
	<div class="header__toggle">
		<i class="bx bx-menu" id="header-toggle"></i>
	</div>
	<h2 class="text-muted" style="margin:0 auto;" ><?php if(isset($_SESSION['NAME'])){ echo "Students"; }else{ echo "Exam"; } ?> Report Panel</h2>
	<a style="text-decoration: none;" href="includes/logout.php">Logout <i class="fas fa-power-off"></i> </a>
</header>
<div class="l-navbar" id="nav-bar">
	<nav class="nav">
		<div>
			<?php if(isset($_SESSION['NAME'])){ ?>
			<a href="#" class="nav__logo">
				<i class="bx bxs-pencil" style="color: white"></i>
				<span class="nav__logo-name">Admin Dashboard</span>
			</a>
			<div class="nav__list">
				<a href="view_admin_profile.php" class="nav__link text-white" style="text-decoration: none;">
					<i class="bx bx-user nav__icon"></i>
					<span class="nav__name">View Profile</span>
				</a>
				<a href="manage_reports.php" class="nav__link text-white" style="text-decoration: none;">
					<i class="bx bx-message-square-detail nav__icon"></i>
					<span class="nav__name">Semester Report</span>
				</a>
				<a href="add_results.php" class="nav__link text-white" style="text-decoration: none;">
					<i class="bx bx-message nav__icon"></i>
					<span class="nav__name">Add Results</span>
				</a>
			</div>
			<?php } else { ?>
			<a href="#" class="nav__logo">
				<i class="bx bxs-pencil" style="color: white"></i>
				<span class="nav__logo-name">Student Dashboard</span>
			</a>
			<div class="nav__list">
				<a href="view_student_profile.php" class="nav__link text-white" style="text-decoration: none;">
					<i class="bx bx-user nav__icon"></i>
					<span class="nav__name">View Profile</span>
				</a>
				<a href="view_report.php" class="nav__link text-white" style="text-decoration: none;">
					<i class="bx bx-message nav__icon"></i>
					<span class="nav__name">View Report</span>
				</a>
			</div>
			<?php } ?>
		</div>
	</nav>
</div>
