<?php
include 'includes/connection.php';
session_start();
$ROLLNO = $_POST['ROLLNO'];
$MAJOR_PROJECT = $_POST['MAJOR_PROJECT'];

//  insert query 
    $sql = "INSERT INTO semester6 (ROLLNO, MAJOR_PROJECT) VALUES('$ROLLNO','$MAJOR_PROJECT')";
    $result = mysqli_query($connection,$sql);
    if($result){
        $_SESSION['status']= "<h4> Marks Added Successfully </h4>";
        header('location:add_results.php?status=ok');
    }else{
        $_SESSION['status']= "<h4> Fail to Add Marks </h4>";
        header('location:add_results.php?status=fail');
    }
?>