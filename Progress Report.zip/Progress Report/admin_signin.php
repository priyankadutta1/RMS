<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
<title>Teacher Sign In</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/sign_up6.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<style>

</style>
</head>
<body style="background-image: linear-gradient(to left top, #1aee0a, #02f03c, #00f358, #00f46e, #00f682, #00f3b6, #00eddb, #00e4ef, #00cdff, #00aeff, #7c7fff, #d627d1);">
<h3 class="text-center mt-5 font-weight-bold">Jorhat Institute Of Science and Technology </h3>
<h4 class="text-center mt-2 font-weight-normal"> Admin SignIn</h4> 
<div class="signup-form">
    <form action="admin_signin_validate.php" method="post">
		<h2>Sign In</h2>
		<p><?php 
            session_start();
            error_reporting(0);
              echo $_SESSION['error'];
              if(isset($_SESSION['error'])){
                unset($_SESSION['error']);  
              }
              ?></p>
		<hr>
		<div class="form-group">
			<div class="input-group">
				<div class="input-group-prepend">
					<span class="input-group-text">
						<i class="fa fa-paper-plane"></i>
					</span>                    
				</div>
				<input type="email" class="form-control" name="email" placeholder="Email Address" required="required">
			</div>
        </div>
		<div class="form-group">
			<div class="input-group">
				<div class="input-group-prepend">
					<span class="input-group-text">
						<i class="fa fa-lock"></i>
					</span>                    
				</div>
				<input type="password" class="form-control" name="password" placeholder="Password" required="required">
			</div>
        </div>
		<div class="form-group">
            <button type="submit" class="btn btn-primary btn-lg">Sign In</button>
						<a style="color:blue; margin-left:7px; " ml-3 href="index.php">Sign In as Student?</a>
        </div>
    </form>
							<!-- <div class="text-center">Don't have an account? <a href="admin_signup.php">Create here</a></div> -->
</div>
</body>
</html>