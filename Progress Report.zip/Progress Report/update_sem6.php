<?php
include 'includes/connection.php';
session_start();
$ROLLNO = $_GET['ROLLNO'];
$MAJOR_PROJECT = $_POST['MAJOR_PROJECT'];
//  insert query 
    $sql = "UPDATE semester6 SET MAJOR_PROJECT='$MAJOR_PROJECT' WHERE ROLLNO = '$ROLLNO'";
    $result = mysqli_query($connection,$sql);
    if($result){
         $_SESSION['status']= "<h5> Marks Edited Successfully </h5>";
        header('location:manage_reports.php?semester=6&&status=ok');
    }else{
        header('location:manage_reports.php?semseter=6&&status=fail');
    }
?>