<?php
include 'includes/connection.php';
session_start();
$ROLLNO = $_POST['ROLLNO'];
$OOPD = $_POST['OOPD'];
$TFCS = $_POST['TFCS'];
$MATHS_3 = $_POST['MATHS_3'];
$OS = $_POST['OS'];
$CG = $_POST['CG'];
$OOPD_LAB = $_POST['OOPD_LAB'];
$CG_LAB = $_POST['CG_LAB'];
//  insert query 
    $sql = "INSERT INTO semester3  (ROLLNO, OOPD ,TFCS ,MATHS_3, OS, CG , OOPD_LAB , CG_LAB ) VALUES('$ROLLNO','$OOPD','$TFCS','$MATHS_3','$OS','$CG','$OOPD_LAB','$CG_LAB')";
    $result = mysqli_query($connection,$sql);
    if($result){
        $_SESSION['status']= "<h4> Marks Added Successfully </h4>";
        header('location:add_results.php?status=ok');
    }else{
    //  echo mysqli_error($connection);
    $_SESSION['status']= "<h4> Fail to Add Marks </h4>";
        header('location:add_results.php?status=fail');
    }
?>