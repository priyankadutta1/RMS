<form action="insert_sem1.php" method="POST">
				<div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">ROLL NO</label>
						<input type="number" name="ROLLNO" class="form-control" id="inputEmail4" placeholder="Student Roll number" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">IIT</label>
						<input type="number" name="IIT" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">CPPS</label>
						<input type="number" name="CPPS" class="form-control" id="inputEmail4" placeholder="mark" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">EC</label>
						<input type="number" name="EC" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">HUMANITIES 1</label>
						<input type="number" name="HUM_1" class="form-control" id="inputEmail4" placeholder="mark" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">MATHEMATICS 1</label>
						<input type="number" name="MATHS_1" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">CPPS LAB</label>
						<input type="number" name="CPPS_LAB" class="form-control" id="inputEmail4" placeholder="mark" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">EC LAB</label>
						<input type="number" name="EC_LAB" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<button type="submit" class="btn btn-primary">Submit</button>
				</div>
			</form>