<?php session_start();
		$query="SELECT * FROM semester1 WHERE ROLLNO = $_SESSION[ROLLNO] ";
		$result=mysqli_query($connection,$query);
  
?>


<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<title>Add Students</title>
		<link rel="stylesheet" href="css/styles.css" type="text/css" />
		<script src="https://kit.fontawesome.com/a076d05399.js"></script>
		<link
			rel="stylesheet"
			href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
		/>
		<link
			href="https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css"
			rel="stylesheet"
		/>
	</head>
	<?php require 'includes/sidebar.php' ?>
	<body id="body-pd">
		<div class="row mt-5 p-4">
			<div class="card-header border-0">
				<h4 class="mb-0">Semester <?php echo $_SESSION['SEMESTER']; ?> Exam Report</h4>
			</div>
				<!-- <?php
          switch($_SESSION['SEMESTER']){
            case 1: require "sem1result.php";break;
            case 2: require "sem2result.php";break;
            case 3: require "sem3result.php";break;
            case 4: require "sem4result.php";break;
            case 5: require "sem5result.php";break;
            default: require "sem6result.php";break;
          }
        ?> -->
		</div>
		<script src="js/main.js"></script>










<table class="table table-bordered table-striped">
	<thead>
		<tr>
			<th scope="col">ROLL-NO</th>
			<th scope="col">IIT</th>
			<th scope="col">CPPS</th>
			<th scope="col">EC</th>
			<th scope="col">HUM-1</th>
			<th scope="col">MATHS-1</th>
			<th scope="col">CPPS-LAB</th>
			<th scope="col">EC-LAB</th>
			<th scope="col">TOTAL MARKS</th>
			<th scope="col">PERCENTAGE</th>
			<?php if(isset($_SESSION['NAME'])): ?>
			<th scope="col">ACTION</th>
			<?php endif ?>
		</tr>
	</thead>
	<tbody>
		<?php if($result==$_SESSION[ROLLNO]){ while($row=mysqli_fetch_array($result)){ ?>
		<tr>
			<td><?php echo $row['ROLLNO'] ?></td>
			<td><?php echo $row['IIT']; ?></td>
			<td><?php echo $row['CPPS']; ?></td>
			<td><?php echo $row['EC']; ?></td>
			<td><?php echo $row['HUM_1']; ?></td>
			<td><?php echo $row['MATHS_1']; ?></td>
			<td><?php echo $row['CPPS_LAB']; ?></td>
			<td><?php echo $row['EC_LAB']; ?></td>
			<td>
				<?php echo ($row['IIT']+$row['CPPS']+$row['EC']+$row['HUM_1']+$row['MATHS_1']+$row['CPPS_LAB']+$row['EC_LAB']) ?>
			</td>
			<td>
				<?php echo round(($row['IIT']+$row['CPPS']+$row['EC']+$row['HUM_1']+$row['MATHS_1']+$row['CPPS_LAB']+$row['EC_LAB'])/700*100)."%" ?>
			</td>
			<?php if(isset($_SESSION['NAME'])){ ?>
			<td>
				<a href="edit_sem1.php?ROLLNO=<?php echo $row['ROLLNO'] ?>"
					>Edit<i class="fas fa-edit ml-2"></i>
				</a>
			</td>
			<?php } ?>
		</tr>
		<?php }} else{ ?>
		<tr>
			<td colspan="10" align="center">RECORD NOT FOUND</td>
		</tr>
		<?php } ?>
	</tbody>
</table>
	</body>
</html>
