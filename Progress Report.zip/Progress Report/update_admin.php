<?php
include 'includes/connection.php';
session_start();
$ID = $_GET['ID'];
$NAME = $_POST['NAME'];
$EMAIL = $_POST['EMAIL'];
  $sql = "UPDATE admin SET NAME='$NAME', EMAIL='$EMAIL' WHERE ID='$ID'";
  $result = mysqli_query($connection,$sql);
  if($result){
    $_SESSION['status']= "<h4>Update Successfully</h4>";
    header('location:view_admin_profile.php?status=ok');
  }else{
   // echo mysqli_error($connection);
    header('location:view_admin_profile.php?status=failed');
  }
?>