-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2021 at 03:46 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `report_card`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `ID` int(10) UNSIGNED NOT NULL,
  `NAME` varchar(100) NOT NULL,
  `EMAIL` varchar(100) NOT NULL,
  `PASSWORD` varchar(200) NOT NULL,
  `CREATE_TIME` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ID`, `NAME`, `EMAIL`, `PASSWORD`, `CREATE_TIME`) VALUES
(2, 'Admin', 'admin@gmail.com', '$2y$10$dAbrHdG7E1XxFQcwd6LrVeUD73JQXHjnhO7GewB4bY4GORc09vrJG', '2021-03-03 05:25:01');

-- --------------------------------------------------------

--
-- Table structure for table `semester1`
--

CREATE TABLE `semester1` (
  `ROLLNO` int(10) UNSIGNED NOT NULL,
  `IIT` int(3) UNSIGNED NOT NULL,
  `CPPS` int(3) UNSIGNED NOT NULL,
  `EC` int(3) UNSIGNED NOT NULL,
  `HUM_1` int(3) UNSIGNED NOT NULL,
  `MATHS_1` int(3) UNSIGNED NOT NULL,
  `CPPS_LAB` int(3) UNSIGNED NOT NULL,
  `EC_LAB` int(3) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `semester2`
--

CREATE TABLE `semester2` (
  `ROLLNO` int(10) NOT NULL,
  `DS` int(3) NOT NULL,
  `CAO` int(3) NOT NULL,
  `MATHS_2` int(3) NOT NULL,
  `HUM_2` int(3) NOT NULL,
  `ENV_SCIENCE` int(3) NOT NULL,
  `DS_LAB` int(3) NOT NULL,
  `CAO_LAB` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `semester3`
--

CREATE TABLE `semester3` (
  `ROLLNO` int(10) NOT NULL,
  `OOPD` int(3) NOT NULL,
  `TFCS` int(3) NOT NULL,
  `MATHS_3` int(3) NOT NULL,
  `OS` int(3) NOT NULL,
  `CG` int(3) NOT NULL,
  `OOPD_LAB` int(3) NOT NULL,
  `CG_LAB` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `semester4`
--

CREATE TABLE `semester4` (
  `ROLLNO` int(10) NOT NULL,
  `VBP` int(3) NOT NULL,
  `DBMS` int(3) NOT NULL,
  `FM` int(3) NOT NULL,
  `CN` int(3) NOT NULL,
  `CD` int(3) NOT NULL,
  `VBP_LAB` int(3) NOT NULL,
  `DBMS_LAB` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `semester5`
--

CREATE TABLE `semester5` (
  `ROLLNO` int(10) NOT NULL,
  `WT` int(3) NOT NULL,
  `ES` int(3) NOT NULL,
  `AI` int(3) NOT NULL,
  `SE` int(3) NOT NULL,
  `MS` int(3) NOT NULL,
  `WT_LAB` int(3) NOT NULL,
  `MINOR_PROJECT` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `semester6`
--

CREATE TABLE `semester6` (
  `ROLLNO` int(10) NOT NULL,
  `MAJOR_PROJECT` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `ID` int(10) NOT NULL,
  `NAME` varchar(100) NOT NULL,
  `SEMESTER` int(1) NOT NULL,
  `ROLLNO` int(10) NOT NULL,
  `EMAIL` varchar(100) NOT NULL,
  `PASSWORD` varchar(100) NOT NULL,
  `CREATE_TIME` timestamp NOT NULL DEFAULT current_timestamp(),
  `UPDATE_TIME` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `email` (`EMAIL`);

--
-- Indexes for table `semester1`
--
ALTER TABLE `semester1`
  ADD PRIMARY KEY (`ROLLNO`);

--
-- Indexes for table `semester2`
--
ALTER TABLE `semester2`
  ADD PRIMARY KEY (`ROLLNO`);

--
-- Indexes for table `semester3`
--
ALTER TABLE `semester3`
  ADD PRIMARY KEY (`ROLLNO`);

--
-- Indexes for table `semester4`
--
ALTER TABLE `semester4`
  ADD PRIMARY KEY (`ROLLNO`);

--
-- Indexes for table `semester5`
--
ALTER TABLE `semester5`
  ADD PRIMARY KEY (`ROLLNO`);

--
-- Indexes for table `semester6`
--
ALTER TABLE `semester6`
  ADD PRIMARY KEY (`ROLLNO`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
