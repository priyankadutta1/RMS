<?php
include 'includes/connection.php';
session_start();
$ROLLNO = $_GET['ROLLNO'];
$IIT = $_POST['IIT'];
$CPPS = $_POST['CPPS'];
$EC = $_POST['EC'];
$HUM_1 = $_POST['HUM_1'];
$MATHS_1 = $_POST['MATHS_1'];
$CPPS_LAB = $_POST['CPPS_LAB'];
$EC_LAB = $_POST['EC_LAB'];
//  insert query 
    $sql = "UPDATE semester1 SET IIT='$IIT' ,CPPS='$CPPS' ,EC='$EC', HUM_1='$HUM_1', MATHS_1='$MATHS_1', CPPS_LAB='$CPPS_LAB', EC_LAB='$EC_LAB' WHERE ROLLNO='$ROLLNO'";
    $result = mysqli_query($connection,$sql);
    if($result){
        $_SESSION['status']= "<h5>Marks Edited Successfully </h5>";
        header('location:manage_reports.php?semester=1&&status=ok');
    }else{
        $_SESSION['status']= "<h4> Fail to Edit Marks </h4>";
        header('location:manage_reports.php?semester=1&&status=fail');
    }
?>