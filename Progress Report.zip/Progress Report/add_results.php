<?php
	require 'includes/session.php';
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<title>Add Students</title>
		<link rel="stylesheet" href="css/style.css" type="text/css" />
		<link
			rel="stylesheet"
			href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
		/>
		<link
			href="https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css"
			rel="stylesheet"
		/>
	</head>
	<?php require 'includes/sidebar.php';  ?>
	<body id="body-pd">
		<div class="row pt-5 mt-5">
			<div class="form-group col-md-4">
			<div>
				<h3>Add Student Records</h3><hr><br>
			</div>
				<label for="inputState">SELECT SEMESTER</label>
				<select
					id="inputState"
					class="form-control"
					onchange="window.location.href='add_results.php?semester='+this.value"
				>
					<option disabled selected>Choose...</option>
						<?php for($i=1;$i<=6;$i++): ?>
							<option <?php if(isset($_GET['semester'])){ if($_GET['semester']==$i){?> selected <?php }} ?> value="<?php echo $i ?>">
								SEMESTER <?php echo $i ?>
							</option>
						<?php endfor ?>
				</select>
			</div>
		</div>
		<div style="color:red;">
			<?php
                if(isset($_SESSION['status'])){

                  echo $_SESSION['status'] ;
                  unset($_SESSION['status']);
                }
            ?>
		</div>
		<?php 
			if(isset($_GET['semester'])){
				$semester = $_GET['semester'];
				switch($semester){
					case "1": require "sem1.php";break;
					case "2": require "sem2.php";break;
					case "3": require "sem3.php";break;
					case "4": require "sem4.php";break;
					case "5": require "sem5.php";break;
					case "6": require "sem6.php";break;
				}
			}
		?>
		<script src="js/main.js"></script>
	</body>
</html>
