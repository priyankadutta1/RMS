<?php require 'includes/session.php'; ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<title>Add Students</title>
		<link rel="stylesheet" href="css/style.css" type="text/css" />
		<link
			rel="stylesheet"
			href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
		/>
		<link
			href="https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css"
			rel="stylesheet"
		/>
	</head>
	<?php require 'includes/sidebar.php';  ?>
	<body id="body-pd">
    <?php 
      require 'includes/connection.php';
      $ROLLNO = $_GET['ROLLNO'];
      $row = mysqli_fetch_array(mysqli_query($connection,"SELECT * FROM semester2 WHERE ROLLNO = $ROLLNO"));
    ?>
		<form class="mt-5 pt-5" action="update_sem2.php?ROLLNO=<?php echo $ROLLNO ?>" method="post" >
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">ROLL NO</label>
						<input type="number" readonly value="<?php echo $row['ROLLNO'] ?>" name="ROLLNO" class="form-control" id="inputEmail4" placeholder="Student Roll number" />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">DS</label>
						<input type="number" value="<?php echo $row['DS'] ?>" name="DS" class="form-control" id="inputPassword4" placeholder="mark" />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">CAO</label>
						<input type="number" value="<?php echo $row['CAO'] ?>" name="CAO" class="form-control" id="inputEmail4" placeholder="mark" />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">MATHEMATICS 2</label>
						<input type="number" value="<?php echo $row['MATHS_2'] ?>" name="MATHS_2" class="form-control" id="inputPassword4" placeholder="mark" />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">HUMANITIES 2</label>
						<input type="number" value="<?php echo $row['HUM_2'] ?>" name="HUM_2" class="form-control" id="inputEmail4" placeholder="mark" />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">ENV SCIENCE</label>
						<input type="number" value="<?php echo $row['ENV_SCIENCE'] ?>" name="ENV_SCIENCE" class="form-control" id="inputPassword4" placeholder="mark" />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">DS LAB</label>
						<input type="number" value="<?php echo $row['DS_LAB'] ?>" name="DS_LAB" class="form-control" id="inputEmail4" placeholder="mark" />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">CAO LAB</label>
						<input type="number" value="<?php echo $row['CAO_LAB'] ?>" name="CAO_LAB" class="form-control" id="inputPassword4" placeholder="mark" />
					</div>
				</div>
				<button type="submit" class="btn btn-primary">Submit</button>
			</form>
		<script src="js/main.js"></script>
	</body>
</html>
