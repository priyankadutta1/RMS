<?php
include 'includes/connection.php';
session_start();
$ROLLNO = $_GET['ROLLNO'];
$NAME = $_POST['NAME'];
$EMAIL = $_POST['EMAIL'];
  $sql = "UPDATE student SET NAME='$NAME', EMAIL='$EMAIL' WHERE ROLLNO='$ROLLNO'";
  $result = mysqli_query($connection,$sql);
  if($result){
    $_SESSION['status']= "<h4>Updated Successfully</h4>";
    header('location:view_student_profile.php?status=ok');
  }else{
    // echo mysqli_error($connection);
    header('location:view_student_profile.php?status=failed');
  }
?>