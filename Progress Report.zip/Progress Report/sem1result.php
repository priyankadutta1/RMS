<?php 
		$query="SELECT * FROM semester1";
		$result=mysqli_query($connection,$query);
  
?>
<table class="table table-bordered table-striped">
	<thead>
		<tr>
			<th scope="col">ROLL-NO</th>
			<th scope="col">IIT</th>
			<th scope="col">CPPS</th>
			<th scope="col">EC</th>
			<th scope="col">HUM-1</th>
			<th scope="col">MATHS-1</th>
			<th scope="col">CPPS-LAB</th>
			<th scope="col">EC-LAB</th>
			<th scope="col">TOTAL MARKS</th>
			<th scope="col">PERCENTAGE</th>
			<?php if(isset($_SESSION['NAME'])): ?>
			<th scope="col">ACTION</th>
			<?php endif ?>
		</tr>
	</thead>
	<tbody>
		<?php if(mysqli_num_rows($result)>=1){ while($row=mysqli_fetch_array($result)){ ?>
		
		<tr>
			<td><?php echo $row['ROLLNO'] ?></td>
			<td><?php echo $row['IIT']; ?></td>
			<td><?php echo $row['CPPS']; ?></td>
			<td><?php echo $row['EC']; ?></td>
			<td><?php echo $row['HUM_1']; ?></td>
			<td><?php echo $row['MATHS_1']; ?></td>
			<td><?php echo $row['CPPS_LAB']; ?></td>
			<td><?php echo $row['EC_LAB']; ?></td>
			<td>
				<?php echo ($row['IIT']+$row['CPPS']+$row['EC']+$row['HUM_1']+$row['MATHS_1']+$row['CPPS_LAB']+$row['EC_LAB']) ?>
			</td>
			<td>
				<?php echo round(($row['IIT']+$row['CPPS']+$row['EC']+$row['HUM_1']+$row['MATHS_1']+$row['CPPS_LAB']+$row['EC_LAB'])/700*100)."%" ?>
			</td>
			<?php if(isset($_SESSION['NAME'])){ ?>
			<td>
				<a href="edit_sem1.php?ROLLNO=<?php echo $row['ROLLNO'] ?>"
					>Edit<i class="fas fa-edit ml-2"></i>
				</a>
			</td>
			<?php } ?>
		</tr>
		<?php }} else{ ?>
		<tr>
			<td colspan="10" align="center">RECORD NOT FOUND</td>
		</tr>
		<?php } ?>
	</tbody>
</table>
