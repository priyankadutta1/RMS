<form action="insert_sem5.php" method="POST">
			<div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">ROLL NO</label>
						<input type="number" name="ROLLNO" class="form-control" id="inputEmail4" placeholder="Student Roll number" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">WT</label>
						<input type="number" name="WT" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">ES</label>
						<input type="number" name="ES" class="form-control" id="inputEmail4" placeholder="mark" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">AI</label>
						<input type="number" name="AI" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">SE</label>
						<input type="number" name="SE" class="form-control" id="inputEmail4" placeholder="mark" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">MS</label>
						<input type="number" name="MS" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">WT LAB</label>
						<input type="number" name="WT_LAB" class="form-control" id="inputEmail4" placeholder="mark" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">MINOR PROJECT</label>
						<input type="number" name="MINOR_PROJECT" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<button type="submit" class="btn btn-primary">Submit</button>
			</div>
			</form>