<form action="insert_sem4.php" method="POST">
				<div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">ROLL NO</label>
						<input type="number" name="ROLLNO" class="form-control" id="inputEmail4" placeholder="Student Roll number" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">VBP</label>
						<input type="number" name="VBP" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">DBMS</label>
						<input type="number" name="DBMS" class="form-control" id="inputEmail4" placeholder="mark" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">FM</label>
						<input type="number" name="FM" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">CN</label>
						<input type="number" name="CN" class="form-control" id="inputEmail4" placeholder="mark" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">CD</label>
						<input type="number" name="CD" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">VBP LAB</label>
						<input type="number" name="VBP_LAB" class="form-control" id="inputEmail4" placeholder="mark" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">DBMS-LAB</label>
						<input type="number" name="DBMS_LAB" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<button type="submit" class="btn btn-primary">Submit</button>
				</div>
			</form>