<?php
  require 'includes/session.php';
  require 'includes/connection.php';
  $SEMESTER = $_SESSION['SEMESTER'];
  $ROLLNO = $_SESSION['ROLLNO'];
  switch($SEMESTER){
    case 1 : $sql = "SELECT * FROM semester1 WHERE ROLLNO =".$_SESSION['ROLLNO'];
 
  
  $result = mysqli_query($connection,$sql); 
  require 'includes/sidebar.php';
  ?>;

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>View Result</title>
	<link rel="stylesheet" href="css/view_report.css" type="text/css" />
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
	<link href="https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css" rel="stylesheet" />
</head>

<body id="body-pd">
	<div id="print">
		<div class="mt-5 p-4">
			<div class="card-header border-0 text-center">
				<h4 class="mb-0">JIST Semester <?php echo $_SESSION['SEMESTER']; ?> Exam Report</h4>
				<h5 class="text-center text-dark">Session 2019-2021</h5>
			</div>

			<table class="table table-bordered table-striped">
				<thead>
					<tr>
						<th scope="col">ROLL-NO</th>
						<th scope="col">IIT</th>
						<th scope="col">CPPS</th>
						<th scope="col">EC</th>
						<th scope="col">HUM-1</th>
						<th scope="col">MATHS-1</th>
						<th scope="col">CPPS-LAB</th>
						<th scope="col">EC-LAB</th>
						<th scope="col">TOTAL MARKS</th>
						<th scope="col">PERCENTAGE</th>
						<?php if(isset($_SESSION['NAME'])): ?>
						<th scope="col">ACTION</th>
						<?php endif ?>
					</tr>
				</thead>
				<tbody>
					<?php if(mysqli_num_rows($result)>=1){ while($row=mysqli_fetch_array($result)){ ?>

					<tr>
						<td><?php echo $row['ROLLNO']  ?></td>
						<td><?php echo $row['IIT']; 
							if ($row['IIT']<24)
							echo "( F )";
							else 
							echo " ( P )";  
						 ?></td>
						<td><?php echo $row['CPPS']; 
							if ($row['CPPS']<24)
							echo "( F )";
							else 
							echo " ( P )";
						?></td>
						<td><?php echo $row['EC'];
						if ($row['EC']<24)
							echo "( F )";
							else 
							echo " ( P )";
						?></td>
						<td><?php echo $row['HUM_1'];
						if ($row['HUM_1']<24)
							echo "( F )";
							else 
							echo " ( P )";
						
						?>
						</td>
						<td><?php echo $row['MATHS_1']; 
						if ($row['MATHS_1']<24)
							echo "( F )";
							else 
							echo " ( P )";
						?></td>
						<td><?php echo $row['CPPS_LAB']; 
						if ($row['CPPS_LAB']<15)
							echo "( F )";
							else 
							echo " ( P )";
						?></td>
						<td><?php echo $row['EC_LAB'];
						if ($row['EC_LAB']<15)
							echo "( F )";
							else 
							echo " ( P )";
						?></td>
						<td>
							<?php echo ($row['IIT']+$row['CPPS']+$row['EC']+$row['HUM_1']+$row['MATHS_1']+$row['CPPS_LAB']+$row['EC_LAB']) ?>
						</td>
						<td>
							<?php echo round(($row['IIT']+$row['CPPS']+$row['EC']+$row['HUM_1']+$row['MATHS_1']+$row['CPPS_LAB']+$row['EC_LAB'])/700*100)."%" ?>
						</td>
						<?php if(isset($_SESSION['NAME'])){ ?>
						<td>
							<a href="edit_sem1.php?ROLLNO=<?php echo $row['ROLLNO'] ?>">Edit<i
									class="fas fa-edit ml-2"></i>
							</a>
						</td>
						<?php } ?>
					</tr>
					<?php }} else{ ?>
					<tr>
						<td colspan="10" align="center">RECORD NOT FOUND</td>
					</tr>
					<?php } ?>
				</tbody>
		</div>
		</table>


	</div>
	<div style="margin: 5% 0 0 85% ; font-weight: 600;">
			<p>Principal Signature</p>
	</div>
	<script src="js/main.js"></script>
	<button onclick="download()" class="print-btn">Print</button>
	<script type="text/javascript">
		function download(){
		    //  var backup = document.body.innerHTML;
			//  var divcontent = document.getElementById(paravalue).innerHTML;
			//  document.body.innerHTML = divcontent;
			 window.print();
			//  document.body.innerHTML = backup; 
			}
	
	</script>
</body>

</html>




<!----------- Second Sem----------->




<?php
    break;
    case 2 : $sql = "SELECT * FROM semester2 WHERE ROLLNO =".$_SESSION['ROLLNO'];
	
	
	
	$result = mysqli_query($connection,$sql); 
  require 'includes/sidebar.php';
  ?>;

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>View Result</title>
	<link rel="stylesheet" href="css/view_report.css" type="text/css" />
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
	<link href="https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css" rel="stylesheet" />
</head>

<body id="body-pd">
	<div id="print">
		<div class="row mt-5 p-4">
			<div class="card-header border-0">
				<h4 class="mb-0">Semester <?php echo $_SESSION['SEMESTER']; ?> Exam Report</h4>
			</div>

			<table class="table table-bordered table-striped">
	<thead>
		<tr>
			<th scope="col">ROLL-NO</th>
			<th scope="col">DS</th>
			<th scope="col">CAO</th>
			<th scope="col">MATHS-2</th>
			<th scope="col">HUM-2</th>
			<th scope="col">ENV-SCIENCE</th>
			<th scope="col">DS-LAB</th>
			<th scope="col">CAO-LAB</th>
			<th scope="col">TOTAL MARKS</th>
			<th scope="col">PERCENTAGE</th>
			<?php if(isset($_SESSION['NAME'])): ?>
			<th scope="col">ACTION</th>
			<?php endif ?>
		</tr>
	</thead>
	<tbody>
		<?php if(mysqli_num_rows($result)>=1){ while($row=mysqli_fetch_array($result)){ ?>
		<tr>
			<td><?php echo $row['ROLLNO']; ?></td>
			<td><?php echo $row['DS'];
				if ($row['DS']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['CAO']; 
				if ($row['CAO']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['MATHS_2']; 
				if ($row['MATHS_2']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['HUM_2']; 
				if ($row['HUM_2']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['ENV_SCIENCE']; 
				if ($row['ENV_SCIENCE']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['DS_LAB']; 
				if ($row['DS_LAB']<15)
							echo "( F )";
							else 
							echo " ( P )";
			
			?></td>
			<td><?php echo $row['CAO_LAB']; 
			if ($row['CAO_LAB']<15)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td>
				<?php echo ($row['DS']+$row['CAO']+$row['MATHS_2']+$row['HUM_2']+$row['ENV_SCIENCE']+$row['DS_LAB']+ $row['CAO_LAB']) ?>
			</td>
			<td>
				<?php echo round(($row['DS']+$row['CAO']+$row['MATHS_2']+$row['HUM_2']+$row['ENV_SCIENCE']+$row['DS_LAB']+ $row['CAO_LAB'])/700*100)."%" ?>
			</td>
			<?php if(isset($_SESSION['NAME'])): ?>
			<td>
				<a href="edit_sem2.php?ROLLNO=<?php echo $row['ROLLNO'] ?>"
					>Edit<i class="fas fa-edit ml-2"></i>
				</a>
			</td>
			<?php endif ?>
		</tr>
		<?php }} else{ ?>
		<tr>
			<td colspan="10" align="center">RECORD NOT FOUND</td>
		</tr>
		<?php } ?>
	</tbody>
</table>



	</div>
	<div style="margin: 5% 0 0 85% ; font-weight: 600;">
			<p>Principal Signature</p>
	</div>
	<script src="js/main.js"></script>
	<button onclick="download()" class="print-btn">Print</button>
	<script type="text/javascript">
		function download(){
		    //  var backup = document.body.innerHTML;
			//  var divcontent = document.getElementById(paravalue).innerHTML;
			//  document.body.innerHTML = divcontent;
			 window.print();
			//  document.body.innerHTML = backup; 
			}
	
	</script>
</body>

</html>

	

<!------------------3rd Sem------------------------>



	
<?php
	
	break;
    case 3 : $sql = "SELECT * FROM semester3 WHERE ROLLNO =".$_SESSION['ROLLNO']; 
	
	$result = mysqli_query($connection,$sql); 
  require 'includes/sidebar.php';
  ?>;

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>View Result</title>
	<link rel="stylesheet" href="css/view_report.css" type="text/css" />
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
	<link href="https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css" rel="stylesheet" />
</head>

<body id="body-pd">
	<div id="print">
		<div class="row mt-5 p-4">
			<div class="card-header border-0">
				<h4 class="mb-0">Semester <?php echo $_SESSION['SEMESTER']; ?> Exam Report</h4>
			</div>

			<table class="table table-bordered table-striped">
	<thead>
		<tr>
			<th scope="col">ROLLNO</th>
			<th scope="col">OOPD</th>
			<th scope="col">TFCS</th>
			<th scope="col">MATHS-3</th>
			<th scope="col">OS</th>
			<th scope="col">CG</th>
			<th scope="col">OOPD-LAB</th>
			<th scope="col">CG-LAB</th>
			<th scope="col">TOTAL</th>
			<th scope="col">PERCENTAGE</th>
			<?php if(isset($_SESSION['NAME'])): ?>
			<th scope="col">ACTION</th>
			<?php endif ?>
		</tr>
	</thead>
	<tbody>
		<?php if(mysqli_num_rows($result)>=1){ while($row=mysqli_fetch_array($result)){ ?>
		<tr>
			<td><?php echo $row['ROLLNO'] 
		
			?></td>
			<td><?php echo $row['OOPD']; 
			if ($row['OOPD']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['TFCS']; 
			if ($row['TFCS']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['MATHS_3']; 
			if ($row['MATHS_3']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['OS'];
			if ($row['OS']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['CG'];
			if ($row['CG']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['OOPD_LAB']; 
			if ($row['OOPD_LAB']<15)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['CG_LAB'];
			if ($row['CG_LAB']<15)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td>
				<?php echo ($row['OOPD']+$row['TFCS']+$row['MATHS_3']+$row['OS']+$row['CG']+$row['CG_LAB']+ $row['OOPD_LAB']) ?>
			</td>
			<td>
				<?php echo round(($row['OOPD']+$row['TFCS']+$row['MATHS_3']+$row['OS']+$row['CG']+$row['CG_LAB']+ $row['OOPD_LAB'])/700*100)."%" ?>
			</td>
			<?php if(isset($_SESSION['NAME'])): ?>
			<td>
				<a href="edit_sem3.php?ROLLNO=<?php echo $row['ROLLNO'] ?>"
					>Edit<i class="fas fa-edit ml-2"></i>
				</a>
			</td>
			<?php endif ?>
		</tr>
		<?php }} else{ ?>
		<tr>
			<td colspan="10" align="center">RECORD NOT FOUND</td>
		</tr>
		<?php } ?>
	</tbody>
</table>



	</div>
	<div style="margin: 5% 0 0 85% ; font-weight: 600;">
			<p>Principal Signature</p>
	</div>
	<script src="js/main.js"></script>
	<button onclick="download()" class="print-btn">Print</button>
	<script type="text/javascript">
		function download(){
		    //  var backup = document.body.innerHTML;
			//  var divcontent = document.getElementById(paravalue).innerHTML;
			//  document.body.innerHTML = divcontent;
			 window.print();
			//  document.body.innerHTML = backup; 
			}
	
	</script>
</body>

</html>
	
	
	
	
	
	
<!------------------4th Sem------------------------>
	
	
	
	
<?php
	break;
    case 4 : $sql = "SELECT * FROM semester4 WHERE ROLLNO =".$_SESSION['ROLLNO']; 
	
	$result = mysqli_query($connection,$sql); 
  require 'includes/sidebar.php';
  ?>;

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>View Result</title>
	<link rel="stylesheet" href="css/view_report.css" type="text/css" />
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
	<link href="https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css" rel="stylesheet" />
</head>

<body id="body-pd">
	<div id="print">
		<div class="row mt-5 p-4">
			<div class="card-header border-0">
				<h4 class="mb-0">Semester <?php echo $_SESSION['SEMESTER']; ?> Exam Report</h4>
			</div>

			<table class="table table-bordered table-striped">
	<thead>
		<tr>
			<th scope="col">ROLLNO</th>
			<th scope="col">VBP</th>
			<th scope="col">DBMS</th>
			<th scope="col">FM</th>
			<th scope="col">CN</th>
			<th scope="col">CD</th>
			<th scope="col">VBP-LAB</th>
			<th scope="col">DBMS-LAB</th>
			<th scope="col">TOTAL</th>
			<th scope="col">PERCENTAGE</th>
			<?php if(isset($_SESSION['NAME'])): ?>
			<th scope="col">ACTION</th>
			<?php endif ?>
		</tr>
	</thead>
	<tbody>
		<?php if(mysqli_num_rows($result)>=1){ while($row=mysqli_fetch_array($result)){ ?>
		<tr>
			<td><?php echo $row['ROLLNO'] ?></td>
			<td><?php echo $row['VBP']; 
			if ($row['VBP']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['DBMS']; 
			if ($row['DBMS']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['FM']; 
			if ($row['FM']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['CN']; 
			if ($row['CN']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['CD']; 
			if ($row['CD']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['VBP_LAB'];
			if ($row['VBP_LAB']<15)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['DBMS_LAB']; 
			if ($row['DBMS_LAB']<15)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td>
				<?php echo ($row['VBP']+$row['DBMS']+$row['FM']+$row['CN']+$row['CD']+$row['VBP_LAB']+ $row['DBMS_LAB']) ?>
			</td>
			<td>
				<?php echo round(($row['VBP']+$row['DBMS']+$row['FM']+$row['CN']+$row['CD']+$row['VBP_LAB']+ $row['DBMS_LAB'])/700*100)."%" ?>
			</td>
			<?php if(isset($_SESSION['NAME'])): ?>
			<td>
				<a href="edit_sem4.php?ROLLNO=<?php echo $row['ROLLNO'] ?>"
					>Edit<i class="fas fa-edit ml-2"></i>
				</a>
			</td>
			<?php endif ?>
		</tr>
		<?php }} else{ ?>
		<tr>
			<td colspan="10" align="center">RECORD NOT FOUND</td>
		</tr>
		<?php } ?>
	</tbody>
</table>


<div style="margin: 5% 0 0 85% ; font-weight: 600;">
			<p>Principal Signature</p>

	</div>
	<script src="js/main.js"></script>
	<button onclick="download()" class="print-btn">Print</button>
	<script type="text/javascript">
		function download(){
		    //  var backup = document.body.innerHTML;
			//  var divcontent = document.getElementById(paravalue).innerHTML;
			//  document.body.innerHTML = divcontent;
			 window.print();
			//  document.body.innerHTML = backup; 
			}
	
	</script>
</body>

</html>
	
	


<!------------------5th Sem------------------------>
	
	

	
	<?php
	break;
    case 5 : $sql = "SELECT * FROM semester5 WHERE ROLLNO =".$_SESSION['ROLLNO']; 
	$result = mysqli_query($connection,$sql); 
  require 'includes/sidebar.php';
  ?>;

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>View Result</title>
	<link rel="stylesheet" href="css/view_report.css" type="text/css" />
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
	<link href="https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css" rel="stylesheet" />
</head>

<body id="body-pd">
	<div id="print">
		<div class="row mt-5 p-4">
			<div class="card-header border-0">
				<h4 class="mb-0">Semester <?php echo $_SESSION['SEMESTER']; ?> Exam Report</h4>
			</div>

			<table class="table table-bordered table-striped">
	<thead>
		<tr>
			<th scope="col">ROLLNO</th>
			<th scope="col">WT</th>
			<th scope="col">ES</th>
			<th scope="col">AI</th>
			<th scope="col">SE</th>
			<th scope="col">MS</th>
			<th scope="col">WT-LAB</th>
			<th scope="col">MINOR-PROJECT</th>
			<th scope="col">TOTAL</th>
			<th scope="col">PERCENTAGE</th>
			<?php if(isset($_SESSION['NAME'])): ?>
			<th scope="col">ACTION</th>
			<?php endif ?>
		</tr>
	</thead>
	<tbody>
		<?php if(mysqli_num_rows($result)>=1){ while($row=mysqli_fetch_array($result)){ ?>
		<tr>
			<td><?php echo $row['ROLLNO'] ?></td>
			<td><?php echo $row['WT']; 
				if ($row['WT']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['ES']; 
			if ($row['ES']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['AI'];
			if ($row['AI']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['SE']; 
			if ($row['SE']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['MS']; 
			if ($row['MS']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['WT_LAB'];
			if ($row['WT_LAB']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo $row['MINOR_PROJECT'];
			if ($row['MINOR_PROJECT']<24)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td>
				<?php echo ($row['WT']+$row['ES']+$row['AI']+$row['SE']+$row['MS']+$row['WT_LAB']+ $row['MINOR_PROJECT']) ?>
			</td>
			<td>
				<?php echo round(($row['WT']+$row['ES']+$row['AI']+$row['SE']+$row['MS']+$row['WT_LAB']+ $row['MINOR_PROJECT'])/700*100)."%" ?>
			</td>
			<?php if(isset($_SESSION['NAME'])): ?>
			<td>
				<a href="edit_sem5.php?ROLLNO=<?php echo $row['ROLLNO'] ?>"
					>Edit<i class="fas fa-edit ml-2"></i>
				</a>
			</td>
			<?php endif ?>
		</tr>
		<?php }} else{ ?>
		<tr>
			<td colspan="10" align="center">RECORD NOT FOUND</td>
		</tr>
		<?php } ?>
	</tbody>
</table>


<div style="margin: 5% 0 0 85% ; font-weight: 600;">
			<p>Principal Signature</p>


	</div>
	<script src="js/main.js"></script>
	<button onclick="download()" class="print-btn">Print</button>
	<script type="text/javascript">
		function download(){
		    //  var backup = document.body.innerHTML;
			//  var divcontent = document.getElementById(paravalue).innerHTML;
			//  document.body.innerHTML = divcontent;
			 window.print();
			//  document.body.innerHTML = backup; 
			}
	
	</script>
</body>

</html>
	
	

<!------------------6th Sem------------------------>

	
	
	<?php
	break;
    default : $sql = "SELECT * FROM semester6 WHERE ROLLNO =".$_SESSION['ROLLNO']; 
	$result = mysqli_query($connection,$sql); 
  require 'includes/sidebar.php';
  ?>;

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>View Result</title>
	<link rel="stylesheet" href="css/view_report.css" type="text/css" />
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
	<link href="https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css" rel="stylesheet" />
</head>

<body id="body-pd">
	<div id="print">
		<div class="row mt-5 p-4">
			<div class="card-header border-0">
				<h4 class="mb-0">Semester <?php echo $_SESSION['SEMESTER']; ?> Exam Report</h4>
			</div>

			<table class="table table-bordered table-striped">
	<thead>
		<tr>
			<th scope="col">ROLLNO</th>
			<th scope="col">MAJOR-PROJECT</th>
			<th scope="col">PERCENTAGE</th>
			<?php if(isset($_SESSION['NAME'])): ?>
			<th scope="col">ACTION</th>
			<?php endif ?>
		</tr>
	</thead>
	<tbody>
		<?php if(mysqli_num_rows($result)>=1){ while($row=mysqli_fetch_array($result)){ ?>
		<tr>
			<td><?php echo $row['ROLLNO'] ?></td>
			<td><?php echo $row['MAJOR_PROJECT']; 
				if ($row['MAJOR_PROJECT']<200)
							echo "( F )";
							else 
							echo " ( P )";
			?></td>
			<td><?php echo round(($row['MAJOR_PROJECT']/700*100))."%"; ?></td>
			<?php if(isset($_SESSION['NAME'])): ?>
			<td>
				<a href="edit_sem6.php?ROLLNO=<?php echo $row['ROLLNO'] ?>"
					>Edit<i class="fas fa-edit ml-2"></i>
				</a>
			</td>
			<?php endif ?>
		</tr>
		<?php }} else{ ?>
		<tr>
			<td colspan="10" align="center">RECORD NOT FOUND</td>
		</tr>
		<?php } ?>
	</tbody>
</table>
<div style="margin: 5% 0 0 85% ; font-weight: 600;">
			<p>Principal Signature</p>

	</div>
	<script src="js/main.js"></script>
	<button onclick="download()" class="print-btn">Print</button>
	<script type="text/javascript">
		function download(){
		    //  var backup = document.body.innerHTML;
			//  var divcontent = document.getElementById(paravalue).innerHTML;
			//  document.body.innerHTML = divcontent;
			 window.print();
			//  document.body.innerHTML = backup; 
			}
	
	</script>
</body>

</html>
	
	
	
<?php	
	
	break;
	
}
?>