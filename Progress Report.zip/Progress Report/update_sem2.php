<?php
include 'includes/connection.php';
session_start();
$ROLLNO = $_GET['ROLLNO'];
$DS = $_POST['DS'];
$CAO = $_POST['CAO'];
$ENV_SCIENCE = $_POST['ENV_SCIENCE'];
$HUM_2 = $_POST['HUM_2'];
$MATHS_2 = $_POST['MATHS_2'];
$CAO_LAB = $_POST['CAO_LAB'];
$DS_LAB = $_POST['DS_LAB'];
//  insert query 
    $sql = "UPDATE semester2 SET DS='$DS',CAO='$CAO',ENV_SCIENCE='$ENV_SCIENCE',HUM_2='$HUM_2',MATHS_2='$MATHS_2',DS_LAB='$DS_LAB',CAO_LAB='$CAO_LAB' WHERE ROLLNO=$ROLLNO";
    $result = mysqli_query($connection,$sql);
    if($result){
       $_SESSION['status']= "<h5>Marks Edited Successfully </h5>";
      header('location:manage_reports.php?semester=2&&status=ok');
    }else{
      // echo mysqli_error($connection);
      header('location:manage_reports.php?semester=2&&status=fail');
    }
?>