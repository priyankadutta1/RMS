<form action="insert_sem6.php" method="POST">
		<div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">Roll No.</label>
						<input type="number" name="ROLLNO" class="form-control" id="inputEmail4" placeholder="Student Roll number" required />
					</div>
					<div class="form-group col-md-6">
						<label for="inputPassword4">Major Project</label>
						<input type="number" name="MAJOR_PROJECT" class="form-control" id="inputPassword4" placeholder="mark" required />
					</div>
				</div>
				<button type="submit" class="btn btn-primary">Submit</button>
		</div>
</form>