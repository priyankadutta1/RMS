<?php 
  $query="SELECT * FROM semester2";
	$result=mysqli_query($connection,$query);
?>
<table class="table table-bordered table-striped">
	<thead>
		<tr>
			<th scope="col">ROLL-NO</th>
			<th scope="col">DS</th>
			<th scope="col">CAO</th>
			<th scope="col">MATHS-2</th>
			<th scope="col">HUM-2</th>
			<th scope="col">ENV-SCIENCE</th>
			<th scope="col">DS-LAB</th>
			<th scope="col">CAO-LAB</th>
			<th scope="col">TOTAL MARKS</th>
			<th scope="col">PERCENTAGE</th>
			<?php if(isset($_SESSION['NAME'])): ?>
			<th scope="col">ACTION</th>
			<?php endif ?>
		</tr>
	</thead>
	<tbody>
		<?php if(mysqli_num_rows($result)>=1){ while($row=mysqli_fetch_array($result)){ ?>
		<tr>
			<td><?php echo $row['ROLLNO']; ?></td>
			<td><?php echo $row['DS']; ?></td>
			<td><?php echo $row['CAO']; ?></td>
			<td><?php echo $row['MATHS_2']; ?></td>
			<td><?php echo $row['HUM_2']; ?></td>
			<td><?php echo $row['ENV_SCIENCE']; ?></td>
			<td><?php echo $row['DS_LAB']; ?></td>
			<td><?php echo $row['CAO_LAB']; ?></td>
			<td>
				<?php echo ($row['DS']+$row['CAO']+$row['MATHS_2']+$row['HUM_2']+$row['ENV_SCIENCE']+$row['DS_LAB']+ $row['CAO_LAB']) ?>
			</td>
			<td>
				<?php echo round(($row['DS']+$row['CAO']+$row['MATHS_2']+$row['HUM_2']+$row['ENV_SCIENCE']+$row['DS_LAB']+ $row['CAO_LAB'])/700*100)."%" ?>
			</td>
			<?php if(isset($_SESSION['NAME'])): ?>
			<td>
				<a href="edit_sem2.php?ROLLNO=<?php echo $row['ROLLNO'] ?>"
					>Edit<i class="fas fa-edit ml-2"></i>
				</a>
			</td>
			<?php endif ?>
		</tr>
		<?php }} else{ ?>
		<tr>
			<td colspan="10" align="center">RECORD NOT FOUND</td>
		</tr>
		<?php } ?>
	</tbody>
</table>
