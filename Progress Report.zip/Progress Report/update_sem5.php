<?php
include 'includes/connection.php';
session_start();
$ROLLNO = $_GET['ROLLNO'];
$WT = $_POST['WT'];
$ES = $_POST['ES'];
$AI = $_POST['AI'];
$SE = $_POST['SE'];
$MS = $_POST['MS'];
$WT_LAB = $_POST['WT_LAB'];
$MINOR_PROJECT = $_POST['MINOR_PROJECT'];
//  insert query 
    $sql = "UPDATE semester5 SET WT='$WT',ES='$ES',AI='$AI',SE='$SE',MS='$MS',WT_LAB='$WT_LAB',MINOR_PROJECT='$MINOR_PROJECT' WHERE ROLLNO = '$ROLLNO' ";
    $result = mysqli_query($connection,$sql);
    if($result){
         $_SESSION['status']= "<h5>Marks Edited Successfully </h5>";
        header('location:manage_reports.php?semester=5&&status=ok');
    }else{
        header('location:manage_reports.php?semester=5&&status=fail');
    }
?>