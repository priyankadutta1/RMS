<?php 
  $query="SELECT * FROM semester6";
	$result=mysqli_query($connection,$query);
?>
<table class="table table-bordered table-striped">
	<thead>
		<tr>
			<th scope="col">ROLLNO</th>
			<th scope="col">MAJOR-PROJECT</th>
			<th scope="col">PERCENTAGE</th>
			<?php if(isset($_SESSION['NAME'])): ?>
			<th scope="col">ACTION</th>
			<?php endif ?>
		</tr>
	</thead>
	<tbody>
		<?php if(mysqli_num_rows($result)>=1){ while($row=mysqli_fetch_array($result)){ ?>
		<tr>
			<td><?php echo $row['ROLLNO'] ?></td>
			<td><?php echo $row['MAJOR_PROJECT']; ?></td>
			<td><?php echo round(($row['MAJOR_PROJECT']/700*100))."%"; ?></td>
			<?php if(isset($_SESSION['NAME'])): ?>
			<td>
				<a href="edit_sem6.php?ROLLNO=<?php echo $row['ROLLNO'] ?>"
					>Edit<i class="fas fa-edit ml-2"></i>
				</a>
			</td>
			<?php endif ?>
		</tr>
		<?php }} else{ ?>
		<tr>
			<td colspan="10" align="center">RECORD NOT FOUND</td>
		</tr>
		<?php } ?>
	</tbody>
</table>
